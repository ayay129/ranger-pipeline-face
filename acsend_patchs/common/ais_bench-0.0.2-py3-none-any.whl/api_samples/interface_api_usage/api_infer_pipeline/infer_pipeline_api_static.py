# Copyright (c) Huawei Technologies Co., Ltd. 2023-2025. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import numpy as np

from ais_bench.infer.interface import InferSession
from ais_bench.infer.common.utils import logger_print


def infer_pipeline_api_static():
    device_id = 0
    data_dir = os.getenv("AISBENCH_INFER_DT_TESTDATA_PATH", "../../sampledata/")
    model_path = os.path.join(data_dir, "add_model/model/add_model_bs1.om")
    # create session of om model for inference
    session = InferSession(device_id, model_path)
    # create new numpy data according inputs info
    shape0 = session.get_inputs()[0].shape
    ndata0 = np.full(shape0, 1).astype(np.float32)
    shape1 = session.get_inputs()[1].shape
    ndata1 = np.full(shape1, 1).astype(np.float32)
    feeds = [ndata0, ndata1]
    feeds_list = [feeds, feeds]
    # execute inference, inputs is ndarray list and outputs is ndarray list
    outputs = session.infer_pipeline(feeds_list, mode='static')
    logger_print("outputs: %s" % outputs)
    # free model resource and device context of session
    session.free_resource()


infer_pipeline_api_static()
